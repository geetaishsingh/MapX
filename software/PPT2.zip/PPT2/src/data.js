// ---------- THEMES (original Ocean Blue + 8 new) ----------
export const THEMES = [
  {
    id: "ocean",
    name: "Ocean Blue",
    main: "#0a84c6",
    dark: "#0b4a6f",
    soft: "#e6f4fb",
  },
  {
    id: "sunset",
    name: "Sunset Orange",
    main: "#f26b1d",
    dark: "#7a3410",
    soft: "#fff0e6",
  },
  {
    id: "forest",
    name: "Forest Green",
    main: "#2e9e5b",
    dark: "#14502d",
    soft: "#e8f7ee",
  },
  {
    id: "berry",
    name: "Berry Pink",
    main: "#d6336c",
    dark: "#7a1b3d",
    soft: "#fdebf2",
  },
  {
    id: "royal",
    name: "Royal Purple",
    main: "#7048e8",
    dark: "#3a237d",
    soft: "#f0ebfd",
  },
  {
    id: "teal",
    name: "Teal Mint",
    main: "#12a594",
    dark: "#0a5b52",
    soft: "#e3f8f5",
  },
  {
    id: "sun",
    name: "Golden Sun",
    main: "#e0a100",
    dark: "#6b4d00",
    soft: "#fff7dc",
  },
  {
    id: "crimson",
    name: "Crimson Red",
    main: "#d92d3a",
    dark: "#6e1219",
    soft: "#fdeaec",
  },
  {
    id: "slate",
    name: "Midnight Slate",
    main: "#475a7a",
    dark: "#1c2433",
    soft: "#eaeef5",
  },
];
export const CLASS_NAME = "Class 1";

function C(
  id,
  title,
  topic,
  words,
  eq,
  ea,
  qq,
  opts,
  ans,
  subject = "English Grammar",
) {
  return {
    id,
    title,
    topic,
    words,
    eq,
    ea,
    qq,
    opts,
    ans,
    subject,
  };
}

export const CHAPTERS = [
  C(
    1,
    "The Alphabet",
    "English alphabet, vowels, consonants and alphabetical order",
    ["Alphabet", "Vowels", "Consonants"],
    "Write the vowels of the English alphabet.",
    "A, E, I, O, U",
    "How many letters are there in the English alphabet?",
    ["24", "26", "28"],
    1,
  ),

  C(
    2,
    "Naming Words (Noun)",
    "Naming words for persons, places, animals, birds and things",
    ["Noun", "Person", "Place"],
    "Identify the naming word: The boy plays.",
    "Boy",
    "Which of these is a naming word?",
    ["Run", "Boy", "Quickly"],
    1,
  ),

  C(
    3,
    "One and Many",
    "Understanding singular and plural nouns",
    ["One", "Many", "Noun"],
    "Change 'one apple' into many.",
    "Many apples",
    "What is the plural of cup?",
    ["Cups", "Cupes", "Cup"],
    0,
  ),

  C(
    4,
    "Gender (He, She)",
    "Using he and she for masculine and feminine nouns",
    ["He", "She", "Gender"],
    "Complete: My mother is a woman. ___ is kind.",
    "She",
    "Which pronoun is used for a boy?",
    ["She", "It", "He"],
    2,
  ),

  C(
    5,
    "Pronoun (Use of I, You, He, She, It, We, They)",
    "Using pronouns in place of naming words",
    ["Pronoun", "I", "They"],
    "Replace 'Rashika and I' with a pronoun.",
    "We",
    "Which is a pronoun?",
    ["School", "They", "Apple"],
    1,
  ),

  C(
    6,
    "Article (A, An, The)",
    "Using a, an and the before nouns",
    ["Article", "A", "An"],
    "Complete: ___ apple.",
    "An apple",
    "Which article is used before 'book'?",
    ["A", "An", "Are"],
    0,
  ),

  C(
    7,
    "Describing Words",
    "Using adjectives to describe nouns",
    ["Adjective", "Quality", "Describe"],
    "Complete: A ___ rose.",
    "A red rose",
    "Which word describes a mango?",
    ["Sweet", "Mango", "Eat"],
    0,
  ),

  C(
    8,
    "This and These",
    "Using this for one nearby thing and these for nearby things",
    ["This", "These", "Near"],
    "Complete: ___ is a book.",
    "This is a book.",
    "Which word is used for many nearby things?",
    ["That", "These", "This"],
    1,
  ),

  C(
    9,
    "That and Those",
    "Using that for one distant thing and those for distant things",
    ["That", "Those", "Far"],
    "Complete: ___ are birds.",
    "Those are birds.",
    "Which word is used for one distant thing?",
    ["Those", "These", "That"],
    2,
  ),

  C(
    10,
    "Action Words (Verbs)",
    "Identifying action words in sentences",
    ["Verb", "Action", "Playing"],
    "Complete: The girl is ___ the drum.",
    "Playing",
    "Which word is an action word?",
    ["Table", "Run", "Blue"],
    1,
  ),

  C(
    11,
    "Use of Is, Are, Am",
    "Using is, are and am in sentences",
    ["Is", "Are", "Am"],
    "Complete: I ___ a student.",
    "I am a student.",
    "Which word completes: She ___ my teacher.",
    ["Are", "Am", "Is"],
    2,
  ),

  C(
    12,
    "Use of Has, Have",
    "Using has and have with nouns and pronouns",
    ["Has", "Have", "Possession"],
    "Complete: He ___ a bicycle.",
    "He has a bicycle.",
    "Which word completes: They ___ books.",
    ["Has", "Have", "Is"],
    1,
  ),

  C(
    13,
    "Position Words",
    "Using position words such as in, on, at, under and in front of",
    ["Position", "Under", "In front of"],
    "Complete: The cat is sitting ___ a tree.",
    "Under",
    "Which word tells the position of something?",
    ["Under", "Happy", "Sing"],
    0,
  ),

  C(
    14,
    "Joining Words",
    "Using conjunctions to join words and sentences",
    ["And", "But", "Or"],
    "Complete: I like apples ___ bananas.",
    "I like apples and bananas.",
    "Which is a joining word?",
    ["Big", "And", "Jump"],
    1,
  ),

  C(
    15,
    "Punctuation",
    "Using full stops, question marks and capital letters",
    ["Full stop", "Question mark", "Capital letter"],
    "Add the correct punctuation: Where do you live",
    "Where do you live?",
    "Which punctuation mark ends a question?",
    [".", "!", "?"],
    2,
  ),

  C(
    16,
    "Composition",
    "Writing related sentences about a person or topic",
    ["Sentence", "Topic", "Composition"],
    "Write a sentence about yourself.",
    "I am a student.",
    "How many sentences does the example composition contain?",
    ["5", "10", "15"],
    1,
  ),

  C(
    17,
    "Comprehension",
    "Reading a passage and answering questions",
    ["Passage", "Understand", "Answer"],
    "Where does Tarun take his dog for a walk?",
    "By the pond",
    "What does Tarun throw for Tiger to fetch?",
    ["A ball", "A book", "A stick"],
    0,
  ),

  C(
    18,
    "Completing Story",
    "Completing a story using suitable words",
    ["Story", "Grapes", "Hungry"],
    "What did the fox want to get?",
    "Grapes",
    "What did the fox say at the end?",
    ["The grapes are sweet.", "The grapes are sour.", "I like grapes."],
    1,
  ),

  C(
    19,
    "Application-Writing",
    "Learning the format of a leave application",
    ["Address", "Salutation", "Subscription"],
    "Who receives a leave application written by a student?",
    "The principal",
    "Which part usually begins with 'Sir/Madam'?",
    ["Salutation", "Body", "Date"],
    0,
  ),

  C(
    20,
    "Let's Communicate",
    "Using greetings and polite expressions in conversations",
    ["Greeting", "Good morning", "Good evening"],
    "What greeting do we use when meeting someone before noon?",
    "Good morning",
    "What do we usually say when parting after 5 p.m.?",
    ["Good morning", "Good night", "Good afternoon"],
    1,
  ),
];

// ---------- SLIDE STRUCTURE (10 SLIDES) ----------
export const SLIDE_COUNT = 10;

export function buildSlides(c) {
  const letters = ["A", "B", "C"];

  return [
    {
      kind: "cover",
      title: c.title,
      tag: `Chapter ${c.id} • ${c.subject}`,
      lines: [c.topic],
    },
    {
      kind: "goals",
      title: "Today we will learn",
      tag: "Goals",
      lines: [
        `Understand: ${c.topic.toLowerCase()}`,
        `Learn the words ${c.words.join(", ")}`,
        "Practise with examples and a quick quiz",
      ],
    },
    {
      kind: "warmup",
      title: "Warm-up",
      tag: "Think first",
      lines: [
        `What do you know about "${c.words[0].toLowerCase()}"?`,
        "Think about the question and share your answer.",
      ],
    },
    {
      kind: "words",
      title: "Magic words",
      tag: "Vocabulary",
      lines: c.words,
    },
    {
      kind: "concept",
      title: c.topic,
      tag: "Big idea",
      lines: [
        `Key word: ${c.words[0]}`,
        `Key word: ${c.words[1]}`,
        `Remember: ${c.words[2]}`,
      ],
    },
    {
      kind: "example",
      title: "Let's understand",
      tag: "Example",
      lines: [c.eq, `Answer: ${c.ea}`],
    },
    {
      kind: "practice",
      title: "Let's practise",
      tag: "Guided practice",
      lines: [`Now you try: write one sentence using "${c.words[0]}".`, "Share your sentence with your classmates."],
    },
    {
      kind: "quiz",
      title: c.qq,
      tag: "Quick quiz",
      lines: c.opts.map((o, i) => `${letters[i]}. ${o}`),
      answer: c.ans,
    },
    {
      kind: "recap",
      title: "Let's recap",
      tag: "Remember",
      lines: [c.topic, `Words: ${c.words.join(" • ")}`, `Remember: ${c.ea}`],
    },
    {
      kind: "home",
      title: "Home challenge",
      tag: "Homework",
      lines: [
        `Write three sentences about "${c.title}".`,
        "Complete one practice activity related to the chapter.",
      ],
    },
  ];
}