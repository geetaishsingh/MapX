import { createRoot } from "react-dom/client";
import { flushSync } from "react-dom";
import html2canvas from "html2canvas";
import PptxGenJS from "pptxgenjs";
import JSZip from "jszip";
import SlideView from "./slides";
import { buildSlides, CLASS_NAME } from "./data";

const W = 1280, H = 720;

// Renders each slide with the SAME component as the preview and captures it as an image
async function renderSlides(c, theme) {
  const host = document.createElement("div");
  host.className = "capture";
  host.style.setProperty("--main", theme.main);
  host.style.setProperty("--dark", theme.dark);
  host.style.setProperty("--soft", theme.soft);
  document.body.appendChild(host);
  const root = createRoot(host);
  await document.fonts.ready;
  const slides = buildSlides(c);
  const images = [];
  for (const [i, s] of slides.entries()) {
    flushSync(() => root.render(<SlideView slide={s} index={i} total={slides.length} />));
    await new Promise((r) => requestAnimationFrame(() => r()));
    await Promise.all([...host.querySelectorAll("img")].map((im) => (im.decode ? im.decode().catch(() => { }) : null)));
    const canvas = await html2canvas(host, {
      scale: 2, backgroundColor: "#ffffff", width: W, height: H, x: 0, y: 0, scrollX: 0, scrollY: 0,
      onclone: (_, el) => { el.style.left = "0px"; el.style.top = "0px"; },
    });
    images.push(canvas.toDataURL("image/jpeg", 0.92));
  }
  root.unmount();
  host.remove();
  return { slides, images };
}

const fileName = (c) => `${CLASS_NAME.replace(/\s+/g, "-")}-Chapter-${c.id}-${c.title.replace(/\s+/g, "-")}.pptx`;

function saveBlob(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

// builds a .pptx (one full-slide picture per slide, same design as preview)
async function chapterPptx(c, theme) {
  const { slides, images } = await renderSlides(c, theme);
  const p = new PptxGenJS();
  p.layout = "LAYOUT_16x9";
  images.forEach((img, i) => {
    const sl = p.addSlide();
    sl.addImage({ data: img, x: 0, y: 0, w: 10, h: 5.625 });
    if (slides[i].kind === "quiz") sl.addNotes(`Answer: ${slides[i].lines[slides[i].answer]}`);
  });
  return p.write({ outputType: "blob" });
}

// one chapter -> one PPT file
export async function exportChapter(c, theme) {
  saveBlob(await chapterPptx(c, theme), fileName(c));
}

// many chapters -> one ZIP containing a PPT per chapter
export async function exportZip(list, theme, zipName, onProgress) {
  const zip = new JSZip();
  for (const [i, c] of list.entries()) {
    zip.file(fileName(c), await chapterPptx(c, theme));
    onProgress?.(i + 1);
  }
  saveBlob(await zip.generateAsync({ type: "blob" }), `${zipName}.zip`);
}